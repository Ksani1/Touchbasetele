package com.example.touchbasetele;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TouchBaseTeleApplication {

    public static void main(String[] args) {
        SpringApplication.run(TouchBaseTeleApplication.class, args);
    }
}
